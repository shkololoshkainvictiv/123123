#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Сборка многостраничного сайта OKKAM в одну страницу (index.html).

Каждый раздел (dublikat, perepak, gtin, zapros, sborka, sverka, reestr, doki)
превращается во вкладку на главной странице:
  * HTML раздела кладётся в <template>, чтобы скрипты/загрузки не срабатывали
    до момента открытия вкладки;
  * стили скоупятся префиксом #sec-XXX (теговые правила переносятся на
    #sec-XXX descendant), поэтому css разных страниц не конфликтует;
  * id внутри раздела получают префик sec-XXX-, а getElementById('...') в JS
    переписывается под новый id;
  * весь inline-JS каждого раздела оборачивается в IIFE и запускается при
    первом открытии вкладки; обработчики window/DOMContentLoaded навешиваются
    сразу (чтобы не терять события), но троттлятся по видимости вкладки;
  * onclick/oninput/onchange-хендлеры публикуются в window.__XxxApi, ссылки
    вида http://okkam.space/<раздел> заменяются на переход по вкладкам.
"""
import re, os, sys

BASE = os.path.dirname(os.path.abspath(__file__))
SITE = os.path.join(BASE, '_site')  # распакованный полный сайт (1.zip) — источник разделов и главной

SECTIONS = [
    dict(key='dublikat', title='Дубликат КИТУ', desc='печать этикеток РТ',
         cls='', icon='<svg viewBox="0 0 24 24" fill="currentColor"><rect x="2" y="4" width="2" height="16"/><rect x="5" y="4" width="1" height="16"/><rect x="7" y="4" width="3" height="16"/><rect x="11" y="4" width="1" height="16"/><rect x="13" y="4" width="2" height="16"/><rect x="16" y="4" width="3" height="16"/><rect x="20" y="4" width="2" height="16"/></svg>',
         api='Dublikat'),
    dict(key='perepak', title='Multon', desc='генерация и печать этикеток',
         cls='card-category-red', icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M7 7h.01M17 7h.01M7 17h.01M14 14h3v3h-3zM17 17v4M14 21h7"/></svg>',
         api='Perepak'),
    dict(key='gtin', title='Перепак', desc='Поиск GTIN и запрос кодов',
         cls='card-category-red', icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.5" y2="16.5"/><line x1="11" y1="7" x2="11" y2="12"/><polyline points="8 9.5 11 12.5 14 9.5"/></svg>',
         api='Gtin'),
    dict(key='sborka', title='Формирование заказа', desc='автоматическое заполнение Excel документа',
         cls='card-category-red', icon='<svg viewBox="0 0 24 24" fill="currentColor"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 2v3H5V5h14zm-7 5h7v3h-7v-3zm-7 3v-3h5v3H5zm0 2h5v4H5v-4zm7 4v-4h7v4h-7z"/></svg>',
         api='Sborka'),
    dict(key='sverka', title='Сверка остатков', desc='ручная сверка остатков SAP и WMS',
         cls='card-category-red-blue', icon='<svg viewBox="0 0 24 24" fill="currentColor"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 10h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"/></svg>',
         api='Sverka'),
    dict(key='reestr', title='Реестр', desc='формирование реестра',
         cls='', icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18M9 3v18"/></svg>',
         api='Reestr'),
    dict(key='zapros', title='Поставка', desc='Запрос товаров для поставки',
         cls='', icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>',
         api='Zapros'),
    dict(key='doki', title='Печать документов', desc='быстрая печать бланков',
         cls='', icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2z"></path><path stroke-linecap="round" stroke-linejoin="round" d="M8 7h8v2H8z"></path><path stroke-linecap="round" stroke-linejoin="round" d="M8 11h8v2H8z"></path><path stroke-linecap="round" stroke-linejoin="round" d="M8 15h6v2H8z"></path></svg>',
         api='Doki'),
    # ---- разделы из полного архива сайта (_site / 1.zip) ----
    dict(key='x5', dir='x5', title='x5', desc='работа с файлом х5',
         cls='card-category-green', icon='<svg viewBox="0 0 24 24"><text x="50%" y="54%" dominant-baseline="middle" text-anchor="middle" font-size="16" font-weight="800" font-family="-apple-system, sans-serif" fill="currentColor">x5</text></svg>',
         api='X5', tag='х5'),
    dict(key='zakaz', dir='zakaz', title='Заказ', desc='формирование заказа',
         cls='', icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>',
         api='Zakaz'),
    dict(key='odinn', dir='1', title='Склад 1/2', desc='выгрузка рядов и ярусов',
         cls='', icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 21V8l9-5 9 5v13"/><path d="M3 21h18M9 21v-6h6v6"/></svg>',
         api='Odinn'),
    dict(key='inv-i', dir='Invi', title='Invi', desc='информационная панель',
         cls='', icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="18" x2="12" y2="21"/></svg>',
         api='InvI'),
    dict(key='panel', dir='panel', title='Панель', desc='загрузка и выгрузка данных',
         cls='', icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3v12m0 0l-4-4m4 4l4-4"/><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/></svg>',
         api='Panel'),
    dict(key='delta', dir='delta', title='Delta', desc='аналитика и графики',
         cls='', icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>',
         api='Delta'),
    dict(key='ermann', dir='ermann', title='Ermann', desc='обработка данных',
         cls='', icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M8 12h8M12 8v8"/></svg>',
         api='Ermann'),
    dict(key='pros4et', dir='pros4et', title='Просчёт', desc='просчёт остатков',
         cls='', icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="2" width="16" height="20" rx="2"/><line x1="8" y1="6" x2="16" y2="6"/><path d="M8 10h1.01M12 10h1.01M16 10h1.01M8 14h1.01M12 14h1.01M16 14h1.01M8 18h1.01M12 18h1.01M16 18h1.01"/></svg>',
         api='Pros4et'),
    dict(key='tabel1', dir='tabel1', title='Табель', desc='табель смен',
         cls='', icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>',
         api='Tabel1'),
    dict(key='zapolnenie1', dir='zapolnenie1', title='Заполнение', desc='заполнение ячеек склада',
         cls='', icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18M9 3v18M15 3v18"/></svg>',
         api='Zapolnenie1'),
    dict(key='perco', dir='perco', title='Perco', desc='проценты и отчёты',
         cls='', icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="19" y1="5" x2="5" y2="19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/></svg>',
         api='Perco'),
    dict(key='invent', dir='invent', title='Инвентаризация', desc='карта склада и отчёты',
         cls='', icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
         api='Invent'),
]

CDN_MAP = {
    'jsbarcode': 'JsBarcode',
    'bwip-js': 'BWIP',
    'xlsx.full.min.js': 'XLSX',
    'xlsx.bundle.js': 'XLSX',
    'exceljs': 'ExcelJS',
    'filesaver': 'saveAs',
}

def cdn_global(src):
    s = src.lower()
    for k, v in CDN_MAP.items():
        if k in s:
            return v
    return None

# ---------------------------------------------------------------- lazy CDN loader
LAZY_CDN = {
    'tailwind': ('https://cdn.tailwindcss.com', '__tailwind_patched'),
    'chart.umd.min.js': ('https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js', 'Chart'),
}
def needs_lazy_cdn(html):
    """Возвращает список ключей ленивых CDN-библиотек, которые нужны разделу."""
    out = []
    low = html.lower()
    if 'cdn.tailwindcss.com' in low or re.search(r'class="[^"]*\b(?:flex|grid|min-h-screen|items-center)\b', low):
        # tailwind-классы используются?
        if re.search(r'(?:class|className)="[^"]*(?:flex|grid|hidden|rounded|text-|bg-|p-\d|m-\d)', html):
            out.append('tailwind')
    if 'chart.umd.min.js' in low or re.search(r'new\s+Chart\s*\(', html):
        out.append('chart.umd.min.js')
    return [k for k in dict.fromkeys(out)]

# ---------------------------------------------------------------- style scoping
def scope_css(css, prefix):
    """prefix all rules with `prefix` (an id selector like #sec-gtin)."""
    out = []
    i, n = 0, len(css)
    def rule(sel, body):
        sel = sel.strip()
        if not sel or sel.startswith('@'):
            return sel + body  # at-rules kept as-is (top-level ones handled below)
        parts = [p.strip() for p in sel.split(',') if p.strip()]
        res = []
        for p in parts:
            if p == 'html' or p.startswith('html ') or p.startswith('html,'):
                p = p.replace('html', prefix, 1)
            elif p == ':root':
                p = prefix
            elif p == 'body' or p.startswith('body '):
                p = prefix + (' ' + p[4:] if len(p) > 4 else '')
            elif p.startswith(prefix):
                pass
            else:
                p = prefix + ' ' + p
            res.append(p)
        return ', '.join(res) + body
    while i < n:
        c = css[i]
        if c in ' \t\r\n;':
            out.append(c); i += 1; continue
        if c == '@':
            j = i
            depth = 0; instr = False
            while j < n:
                ch = css[j]
                if instr:
                    if ch == '\\': j += 2; continue
                    if ch == '"' or ch == "'": instr = False
                elif ch == '"' or ch == "'":
                    instr = True
                elif ch == '{':
                    depth += 1
                elif ch == '}':
                    depth -= 1
                    if depth == 0:
                        j += 1; break
                elif ch == ';' and depth == 0:
                    break
                j += 1
            stmt = css[i:j]
            m = re.match(r'@([a-zA-Z-]+)\s*([^{;]*)', stmt)
            name = (m.group(1) or '').lower() if m else ''
            if name in ('media', 'supports', 'layer'):
                inner = stmt[stmt.find('{') + 1: stmt.rfind('}')]
                out.append('@%s%s{%s}' % (name, m.group(2), scope_css(inner, prefix)))
            else:
                out.append(stmt)
            i = j
            continue
        # ordinary rule: selector until first top-level '{'
        j = i; instr = False
        while j < n:
            ch = css[j]
            if instr:
                if ch == '\\': j += 2; continue
                if ch == '"' or ch == "'": instr = False
            elif ch == '"' or ch == "'":
                instr = True
            elif ch == '{':
                break
            j += 1
        if j >= n:
            break
        sel = css[i:j]
        # find matching '}'
        k = j + 1; depth = 1; instr = False
        while k < n and depth:
            ch = css[k]
            if instr:
                if ch == '\\': k += 2; continue
                if ch == '"' or ch == "'": instr = False
            elif ch == '"' or ch == "'":
                instr = True
            elif ch == '{':
                depth += 1
            elif ch == '}':
                depth -= 1
            k += 1
        body = css[j:k - 1]  # without braces
        out.append(rule(sel, '{' + body + '}'))
        i = k
    return ''.join(out)

# ---------------------------------------------------------------- js rewriting
def rewrite_js(js, dom_ids, root_id, section_key, api_name, exposed_fns):
    # 1. getElementById('old') -> корневой прокси рантайма (см. __GID)
    def gid(m):
        q, old = m.group(1), m.group(2)
        if old in dom_ids:
            return "__GID(%s%s%s)" % (q, old, q)
        return m.group(0)
    js = re.sub(r"getElementById\(\s*(['\"])([^'\"]+)\1\s*\)", gid, js)

    # 2. querySelector(All)('#someId') тоже переписываем под прокси
    def qs(m):
        fn, q, sel = m.group(1), m.group(2), m.group(3)
        if sel[1:] in dom_ids:
            return "%s(__SEL(%s%s%s))" % (fn, q, sel, q)
        return m.group(0)
    js = re.sub(r"(querySelector(?:All)?)\(\s*(['\"])(#[A-Za-z][\w:-]*)\2", qs, js)

    # 3. относительные URL ассетов -> __U('...'): runtime подставит URL папки раздела.
    #    Только в явных местах: присваивания src/href/action, .getAttribute('...'), fetch/URL строкой.
    def _is_asset(u):
        return bool(re.match(r'^[\w./%+~@-]*\.(pdf|xlsx|xls|csv|json|docx?|pptx?|zip|png|jpe?g|svg|ico|js)(\?[\w=&.-]*)?$', u)) and \
               not re.match(r'^[a-zA-Z][\w+.-]*://', u) and not u.startswith('/') and not u.startswith('data:')
    def fixattr(m):
        pre, q, u = m.group(1), m.group(2), m.group(3)
        if _is_asset(u):
            return "%s__U(%s%s%s)" % (pre, q, u, q)
        return m.group(0)
    js = re.sub(r"(\.(?:src|href|action|formaction)\s*=\s*)(['\"])([^'\"\n]+?)\2", fixattr, js)
    js = re.sub(r"(\.getAttribute\(\s*)(['\"])([^'\"\n]+?)\2", fixattr, js)

    # 4. fetch('...') / new URL('...', ...) с относительным путём (php или ассет) -> __U('...')
    def fixfetch(m):
        pre, q, path = m.group(1), m.group(2), m.group(3)
        if re.match(r'^https?:', path) or path.startswith('__'):
            return m.group(0)
        if path.endswith('.php') or path.endswith('.php?t=') or _is_asset(path.split('?')[0] + '?x') or '?' in path:
            return "%s__U(%s%s%s)" % (pre, q, path, q)
        return m.group(0)
    js = re.sub(r"((?:fetch|\.open\s*\(\s*['\"]GET['\"]\s*,|new URL)\(?\s*)(['\"])([^'\"\n]*\.(?:php|xlsx|xls|csv|json|docx?|zip|png|jpe?g|svg|ico)[^'\"\n]*)\2", fixfetch, js)

    # 4b. шаблонные строки `api.php?...` внутри fetch(`...`) -> конкатенация с __U('api.php?...')
    def fixtpl(m):
        pre, head, tail = m.group(1), m.group(2), m.group(3)
        return "%s__U('%s')%s" % (pre, head.replace("'", "\\'"), (' + `%s`' % tail) if tail else '')
    js = re.sub(r"(fetch\(\s*`)((?:[^`$]|(?!\$\{)[\$])*?\.php(?:[^$`]|(?!\$\{)[\$])*?)\$\{([^`]*)\}`",
                lambda m: fixtpl(m), js)
    js = re.sub(r"(fetch\(\s*`)((?:[^`$]|(?!\$\{)[\$])*?\.php(?:[^$`]|(?!\$\{)[\$])*)`",
                lambda m: "%s__U('%s')" % (m.group(1), m.group(2).replace("'", "\\'")), js)

    # 5. location.reload() -> наш помощник перезагрузки раздела на месте
    js = js.replace("location.reload()", "__reloadSection('%s')" % section_key)
    js = js.replace("window.location.href='#'", "void 0")
    # ссылки на страницы сайта -> вкладки/домашняя
    for other in SECTIONS:
        od = other.get('dir', other['key'])
        js = re.sub(r"(https?://(?:www\.)?okkam\.space/%s)/?" % re.escape(od),
                    r"#tab:%s" % other['key'], js)
    js = re.sub(r"(['\"])(?:https?://)?(?:www\.)?okkam\.space/?\1", r"\1#\1", js)

    # 7. expose functions used from inline HTML attributes
    JS_KW = set('''break case catch class const continue debugger default delete do else enum export extends
false finally for function if import in instanceof new null return super switch this throw true try typeof var
void while with yield let await static'''.split())
    exposed_fns = [f for f in exposed_fns if f not in JS_KW]
    exports = '\n'.join("  window.%s.%s = %s;" % (api_name, f, f) for f in exposed_fns)

    wrap = """
(function(){
'use strict';
var __SEC_ROOT = document.getElementById('%(root)s');
var __ACTIVE = false;
if (!__SEC_ROOT) return;
/* прокси id: старые id раздела -> новые (с префиксом), пока раздел активен */
var __DOM_IDS = %(domids)s;
window.__secProxy['%(key)s'] = {root: '%(root)s', ids: __DOM_IDS};
try{
%(js)s
}catch(err){ console.error('Ошибка в разделе %(key)s:', err); }
window.__sectionBoot = window.__sectionBoot || {};
window.__sectionBoot['%(key)s'] = function(active){ __ACTIVE = !!active; };
window['%(api)s'] = window['%(api)s'] || {};
%(exports)s
})();
""" % dict(root=root_id, key=section_key, api=api_name,
           js=js, exports=exports,
           domids='null')
    # карта id вставим отдельно (чтобы не возиться с экранированием %)
    idmap = '{' + ','.join("'%s':1" % i for i in sorted(dom_ids)) + '}'
    wrap = wrap.replace("__DOM_IDS = null;", "__DOM_IDS = %s;" % idmap)
    return wrap

# ---------------------------------------------------------------- main build
def extract(html):
    m = re.search(r'<head[^>]*>(.*?)</head>', html, re.S | re.I)
    head = m.group(1)
    styles = re.findall(r'<style[^>]*>(.*?)</style>', head, re.S | re.I)
    ext_scripts = re.findall(r'<script[^>]*\bsrc="([^"]+)"[^>]*>\s*</script>', head)
    body_m = re.search(r'<body[^>]*>(.*)</body>', html, re.S | re.I)
    body = body_m.group(1)
    scripts = re.findall(r'<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>', body, re.S | re.I)
    body_html = re.sub(r'<script(?![^>]*\bsrc=)[^>]*>.*?</script>', '', body, flags=re.S | re.I)
    body_html = re.sub(r'<script[^>]*\bsrc="[^"]*"[^>]*>\s*</script>', '', body_html, flags=re.S | re.I)
    return head, styles, ext_scripts, body_html, '\n'.join(scripts)

def build():
    all_styles = []
    templates = []
    tabs = []
    boot_list = []
    cdn_srcs = set()

    for s in SECTIONS:
        key = s['key']
        d = s.get('dir', key)
        root_id = 'sec-' + key
        path = os.path.join(SITE, d, 'index.html')
        html = open(path, encoding='utf-8').read()
        head, styles, ext_scripts, body_html, js = extract(html)

        # collect cdn globals
        script_tags = []
        for src in ext_scripts:
            g = cdn_global(src)
            script_tags.append('<script src="%s"%s defer></script>' % (src, (' data-global="%s"' % g) if g else ''))
            cdn_srcs.add(src)

        # ---- ids
        dom_ids = set(re.findall(r'\bid="([^"]+)"', body_html))
        renamed_body = re.sub(r'\bid="([^"]+)"', lambda m: 'id="%s-%s"' % (root_id, m.group(1)), body_html)
        renamed_body = re.sub(r'\bfor="([^"]+)"', lambda m: 'for="%s-%s"' % (root_id, m.group(1)) if m.group(1) in dom_ids else m.group(0), renamed_body)

        # remove back button (navigation is handled by tabs)
        renamed_body = re.sub(r'<a\b[^>]*class="back-btn"[^>]*>.*?</a>', '', renamed_body, flags=re.S)
        # any leftover links to okkam.space sections -> tab anchors
        for other in SECTIONS:
            od = other.get('dir', other['key'])
            renamed_body = re.sub(r'<a\b([^>]*?)href="(?:https?://)?(?:www\.)?okkam\.space/%s/?"' % re.escape(od),
                                  r'<a\1 href="#tab:%s"' % other['key'], renamed_body)
        renamed_body = re.sub(r'<a\b([^>]*?)href="(?:https?://)?(?:www\.)?okkam\.space/?[^"]*"',
                              r'<a\1 href="#" onclick="return __goHome()"', renamed_body)

        # ---- styles
        css = '\n'.join(styles)
        scoped = scope_css(css, '#' + root_id)
        # neutralise global print/body backgrounds inside the page context
        scoped = scoped.replace('@page', '/*@page*/')
        all_styles.append('/* ===== раздел: %s ===== */\n%s' % (s['title'], scoped))

        # ---- js
        exposed = sorted(set(re.findall(r'on(?:click|change|input|submit|blur|focus|keyup)="([A-Za-z_$][\w$]*)\(', renamed_body)))
        # inline-хендлеры вызывают глобальные функции разделов — перенаправляем в API-окно раздела
        for fn in exposed:
            renamed_body = re.sub(r'\bon(click|change|input|submit|blur|focus|keyup)="([\s\S]*?)"',
                lambda m: 'on%s="%s"' % (m.group(1), re.sub(r'(?<![\w.$])%s\(' % re.escape(fn), 'window.%s.%s(' % (s['api'], fn), m.group(2))),
                renamed_body)
        js2 = rewrite_js(js, dom_ids, root_id, key, s['api'], exposed)

        templates.append('<template id="%s-tpl">\n%s\n</template>' % (root_id, renamed_body.strip()))
        boot_list.append("  '%s': function(active){ if (window.__sectionBoot && window.__sectionBoot['%s']) window.__sectionBoot['%s'](active); }," % (key, key, key))

        arrow = '<div class="card-arrow"><svg viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></div>'
        corner = ('<span class="card-corner-tag-green">%s</span>' % s['tag']) if s.get('tag') else ''
        tabs.append('''    <a href="#tab:%s" class="card %s" data-tab="%s">
      %s
      <div class="icon-box">%s</div>
      <div class="card-content">
        <h2 class="card-title">%s</h2>
        <p class="card-desc">%s</p>
      </div>
      %s
    </a>''' % (key, s['cls'], key, arrow, s['icon'], s['title'], s['desc'], corner))

        # stash for later assembly
        s['_js'] = js2
        s['_scripts'] = '\n'.join(script_tags)

    # assemble index.html
    home = open(os.path.join(SITE, 'index.html'), encoding='utf-8').read()

    # 0) защита от повторной сборки: берём исходную главную из _site (git-версия не нужна)

    # 1) inject extra styles before </style> of homepage (last style block end)
    extra_css = '\n'.join(all_styles)
    idx = home.rfind('</style>')
    home = home[:idx] + '\n</style>\n<style id="sections-style">\n' + extra_css + '\n</style>\n' + home[idx + len('</style>'):]

    # 2) replace <main class="grid"> ... </main> with tab cards + sections
    grid_start = home.find('<main class="grid">')
    grid_end = home.find('</main>', grid_start) + len('</main>')
    sections_html = []
    for s in SECTIONS:
        key = s['key']
        sections_html.append('''  <section class="tab-section" id="sec-%s" role="tabpanel" aria-label="%s">
    <button class="tab-back" data-back>← Назад к меню</button>
    <div class="tab-inner"></div>
  </section>''' % (key, s['title']))
    new_main = ('  <main class="grid" id="menuGrid">\n' + '\n\n'.join(tabs) + '''
    <div class="card disabled">
      <span class="badge badge-soon">скоро</span>
      <div class="icon-box"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="9"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg></div>
      <div class="card-content">
        <h2 class="card-title">???</h2>
        <p class="card-desc">если есть информацию которую я могу выдернуть и отобразить - пишите на вацап</p>
      </div>
    </div>
  </main>
''' + '\n'.join(templates) + '\n' + '\n'.join(sections_html))
    home = home[:grid_start] + new_main + home[grid_end:]

    # 3) header subtitle tweak
    home = home.replace('Выберите нужный раздел для работы', 'Все инструменты на одной странице — выберите раздел')

    # 4) add runtime scripts before </body>
    per_section_js = '\n'.join('<script id="js-%s" type="text/plain">\n%s\n</script>' % (s['key'], s['_js']) for s in SECTIONS)
    runtime = """
<!-- CDN-библиотеки всех разделов -->
%(cdn)s

<div id="tabLoading" class="tab-loading" hidden><div class="tab-spinner"></div><span>Загрузка раздела…</span></div>

<script>
/* ================= ОДНОСТРАНИЧНЫЙ РАНТАЙМ ================= */
var SECTION_ORIGIN = 'http://okkam.space';
var SECTION_SCRIPTS = {};
document.querySelectorAll('script[type="text/plain"]').forEach(function(sc){
  SECTION_SCRIPTS[sc.id.replace('js-','')] = sc.textContent;
});
var __secProxy = {};      /* key -> {root, ids}: карта id раздела */
var __activeKey = null;
window.__secProxy = __secProxy;

/* прокси getElementById для кода разделов: старый id -> префиксованный id вкладки */
function __GID(id){
  var p = __activeKey && __secProxy[__activeKey];
  if (p && p.ids[id]) return document.getElementById(p.root + '-' + id);
  return document.getElementById(id);
}
function __SEL(sel){
  var p = __activeKey && __secProxy[__activeKey];
  if (p){
    var m = /^#([A-Za-z][\\w:-]*)([\\s\\S]*)$/.exec(sel);
    if (m && p.ids[m[1]]) return '#' + p.root + '-' + m[1] + (m[2] || '');
  }
  return sel;
}
/* относительные пути ассетов/скриптов -> абсолютный URL папки активного раздела */
function __U(path){
  path = String(path || '').replace(/^\\.\\//, '');
  if (/^(https?:)?\\/\\//.test(path) || path.charAt(0) === '/' || path.indexOf('data:') === 0 || path.indexOf('blob:') === 0) return path;
  var base = SECTION_ORIGIN + '/';
  if (__activeKey) base += __activeKey + '/';
  return base + path;
}

/* обход DOM раздела: чиним относительные url в атрибутах и строковые литералы вида __U(...) */
function __fixUrlsInNode(node){
  var all = [];
  if (node.querySelectorAll) all = Array.prototype.slice.call(node.querySelectorAll('*'));
  all.unshift(node);
  all.forEach(function(el){
    ['action','href','src','formaction'].forEach(function(a){
      var v = el.getAttribute && el.getAttribute(a);
      if (!v) return;
      if (/^https?:|^data:|^blob:|^mailto:|^javascript:|^#/i.test(v)) return;
      if (a === 'href' && /^\\./.test(v) === false && v.indexOf('/') === 0) return;
      if (/\\.(php|xlsx|xls|csv|json|png|jpe?g|svg|ico|pdf)/i.test(v) || a === 'action' || a === 'formaction'){
        el.setAttribute(a, __U(v));
      }
    });
  });
}

/* печать: во время print показываем только активную вкладку */
window.addEventListener('beforeprint', function(){
  var act = document.querySelector('.tab-section.active');
  if (act) document.body.setAttribute('data-printing-tab', act.id);
});
window.addEventListener('afterprint', function(){
  document.body.removeAttribute('data-printing-tab');
});

function __goHome(){ location.hash = ''; showTab(null); return false; }

var loadedSections = {};
function currentHashTab(){
  var m = /^#tab:([a-z0-9_-]+)/.exec(location.hash || '');
  return m ? m[1] : null;
}

function showTab(key){
  var menu = document.getElementById('menuGrid');
  var sections = document.querySelectorAll('.tab-section');
  var loading = document.getElementById('tabLoading');
  if (!key){
    sections.forEach(function(s){ s.classList.remove('active'); var k2 = s.id.replace('sec-',''); if (window.__sectionBoot && window.__sectionBoot[k2]) window.__sectionBoot[k2](false); });
    menu.hidden = false;
    document.body.classList.remove('tab-open');
    __activeKey = null;
    history.replaceState(null, '', location.pathname + location.search);
    window.scrollTo(0, 0);
    return;
  }
  var target = document.getElementById('sec-' + key);
  if (!target) return;
  menu.hidden = true;
  sections.forEach(function(s){
    var on = (s === target);
    s.classList.toggle('active', on);
    var k2 = s.id.replace('sec-','');
    if (window.__sectionBoot && window.__sectionBoot[k2]) window.__sectionBoot[k2](on);
  });
  __activeKey = key;
  document.body.classList.add('tab-open');
  loading.hidden = false;
  ensureSection(key, function(){
    loading.hidden = true;
    window.scrollTo(0, 0);
  });
}

function extractScripts(node){
  var out = [];
  Array.prototype.slice.call(node.querySelectorAll('script')).forEach(function(sc){
    out.push({src: sc.getAttribute('src'), global: sc.getAttribute('data-global'), text: sc.textContent});
    sc.parentNode.removeChild(sc);
  });
  return out;
}

function appendCdn(list, done){
  var queue = list.filter(function(s){ return s.src && (!s.global || typeof window[s.global] === 'undefined'); });
  function next(){
    if (!queue.length){ done(); return; }
    var s = queue.shift();
    var el = document.createElement('script');
    el.src = /^https?:/.test(s.src) ? s.src : SECTION_ORIGIN + '/' + (__activeKey ? __activeKey + '/' : '') + s.src;
    el.onload = next; el.onerror = next;
    document.head.appendChild(el);
  }
  next();
}

function runSectionCode(key){
  var root = document.getElementById('sec-' + key);
  var e = document.createElement('script');
  e.textContent = SECTION_SCRIPTS[key] || '';
  root.appendChild(e);
  if (window.__sectionBoot && window.__sectionBoot[key]) window.__sectionBoot[key](true);
}

function ensureSection(key, done){
  if (loadedSections[key]){
    if (window.__sectionBoot && window.__sectionBoot[key]) window.__sectionBoot[key](true);
    done && done(); return;
  }
  loadedSections[key] = true;
  __activeKey = key;
  var root = document.getElementById('sec-' + key);
  var inner = root.querySelector('.tab-inner');
  var tpl = document.getElementById('sec-' + key + '-tpl');
  var frag = tpl.content.cloneNode(true);
  var scripts = extractScripts(frag);
  while (frag.firstChild) inner.appendChild(frag);
  __fixUrlsInNode(inner);
  appendCdn(scripts, function(){ runSectionCode(key); done && done(); });
}

document.addEventListener('click', function(e){
  var card = e.target.closest ? e.target.closest('a[data-tab]') : null;
  if (card){ e.preventDefault(); location.hash = '#tab:' + card.getAttribute('data-tab'); return; }
  var back = e.target.closest ? e.target.closest('[data-back]') : null;
  if (back){ e.preventDefault(); location.hash = ''; return; }
});
window.addEventListener('hashchange', function(){ showTab(currentHashTab()); });
window.addEventListener('DOMContentLoaded', function(){ showTab(currentHashTab()); });

function __reloadSection(key){
  loadedSections[key] = false;
  var root = document.getElementById('sec-' + key);
  var inner = root.querySelector('.tab-inner');
  inner.innerHTML = '';
  ensureSection(key, function(){});
}
</script>

%(perjs)s
""" % {'cdn': '\\n'.join(sorted('<script src="%s"%s defer></script>' % (src, (' data-global="%s"' % cdn_global(src)) if cdn_global(src) else '') for src in cdn_srcs)),
        'perjs': per_section_js}

    idx = home.rfind('</body>')
    home = home[:idx] + runtime + home[idx:]

    # 5) small css additions for tabs
    tab_css = '''
.tab-section{display:none;width:100%;max-width:1200px;margin:0 auto}
.tab-section.active{display:block;animation:tabFade .35s ease}
@keyframes tabFade{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
.tab-back{margin:0 0 18px;padding:10px 18px;border-radius:12px;border:1px solid rgba(0,0,0,.08);background:#fff;color:#e85a1e;font-weight:700;font-size:14px;cursor:pointer;box-shadow:4px 6px 16px rgba(30,30,60,.08);transition:all .25s}
.tab-back:hover{transform:translateY(-2px);box-shadow:6px 9px 20px rgba(232,90,30,.2)}
body.tab-open .ticker-wrap{display:none}
.tab-loading{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;gap:12px;background:rgba(228,229,235,.85);backdrop-filter:blur(3px);z-index:2000;font-weight:600;color:#e85a1e}
.tab-loading[hidden]{display:none}
.tab-spinner{width:26px;height:26px;border-radius:50%;border:3px solid rgba(232,90,30,.25);border-top-color:#e85a1e;animation:tabSpin .8s linear infinite}
@keyframes tabSpin{to{transform:rotate(360deg)}}
'''
    idx = home.find('</style>')
    home = home[:idx] + tab_css + home[idx:]

    open(os.path.join(BASE, 'index.html'), 'w', encoding='utf-8').write(home)
    print('OK, written index.html (%d bytes)' % len(home.encode('utf-8')))

if __name__ == '__main__':
    build()